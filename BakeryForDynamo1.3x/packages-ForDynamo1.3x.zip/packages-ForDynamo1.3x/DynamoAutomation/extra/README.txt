For more information on how to use this package go to 
https://github.com/andydandy74/DynamoAutomation