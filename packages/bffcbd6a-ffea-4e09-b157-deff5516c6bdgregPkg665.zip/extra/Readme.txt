For more information on how to use these nodes go to 
https://github.com/andydandy74/ClockworkForDynamo